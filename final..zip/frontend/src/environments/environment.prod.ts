export const environment = {
  production: true,
  apiUrl: 'https://your-backend.vercel.app' // Replace with your Vercel backend URL
};
