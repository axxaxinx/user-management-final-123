export enum Role {
    User = 'User',
    Admin = 'Admin'
}

export enum Status {
    Active = 'Active',
    Inactive = 'Inactive'
}