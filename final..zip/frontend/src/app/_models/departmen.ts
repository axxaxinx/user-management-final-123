﻿import { Role } from './role';

export class Department {
    id: string;
    name: string;
    description: string;
}