﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'overview.component.html',
    standalone: false
})
export class OverviewComponent { }