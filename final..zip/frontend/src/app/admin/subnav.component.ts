import { Component } from '@angular/core';

@Component({
    templateUrl: 'subnav.component.html',
    standalone: false
})
export class SubNavComponent { }