﻿import { Component } from '@angular/core';

@Component({
    templateUrl: 'layout.component.html',
    standalone: false
})
export class LayoutComponent { }