module.exports = {
    Admin: 'Admin',
    User: 'User'
}