module.exports = {
    Active: 'Active',
    InActive: 'InActive'
}